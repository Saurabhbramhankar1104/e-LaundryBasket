package com.app.entities;

public enum PaymentStatus {
	PENDING,COMPLETED,REFUNDED
}
