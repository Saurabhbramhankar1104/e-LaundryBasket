const config = {
  serverURL: "http://localhost:8081/eLaundryBasket",
};

export default config;
